// just compile as c++
#include "dbHeaderTest.c"
